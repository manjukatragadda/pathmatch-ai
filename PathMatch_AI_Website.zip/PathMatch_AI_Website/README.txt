PATHMATCH AI — WEBSITE DEMO
============================

Files
- index.html: responsive landing page and interactive front-end demo.

Features included
- Responsive landing page with hero section and calls to action
- Product benefits and how-it-works sections
- Interactive student profile form
- Rule-based sample internship role recommendations
- Illustrative fit score and skills-to-explore suggestions
- FAQ, contact form, and footer
- No profile data is sent to a server or saved

Important honesty note
This is a prototype, not a production AI system. The matching percentages and role suggestions are illustrative and rule-based, not validated predictions. It does not display verified live internship vacancies. Before using the contact form, replace REPLACE-WITH-YOUR-TEAM-EMAIL@example.com in index.html with your team's actual email address.

HOW TO OPEN
1. Download and unzip the package.
2. Open the folder.
3. Double-click index.html. It opens in Chrome or another browser.

HOW TO PUBLISH FOR FREE (GitHub Pages)
1. Create/sign in to a GitHub account at https://github.com/
2. Create a new public repository, e.g. pathmatch-ai.
3. Upload index.html (and this README if you want).
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select main and /(root), then Save.
7. Wait for the published URL shown on the Pages screen. Copy that URL into your assignment.
The exact menus can change. Do not submit the GitHub repository URL as the live website URL unless the form specifically asks for the repository.
